from list.naver_id import *


a = {"message":{"@type":"response","@service":"korea.naverkoreaservice.community.cafe","@version":"1.0.0","status":"200","result":{"msg":"Success","cafeUrl":"specup","articleId":6249387,"articleUrl":"https://cafe.naver.com/specup/6249387"}}}



naver_id18 = ["이태리어 / 일본어","shinesteps","stepcare1347","1qEJOJK8CXB9ckEOBEBL","COIeAQeWYA"] 
# 네이버 계정 및 앱 정보
naver_id = naver_id18[1] #네이버 아이디
naver_pw = naver_id18[2] #네이버 비밀번호
naver_cid = naver_id18[3] #클라이언트 아이디
naver_csec = naver_id18[4] #클라이언트 시크릿
print(a["message"]["result"]["articleUrl"])
print(str(3))