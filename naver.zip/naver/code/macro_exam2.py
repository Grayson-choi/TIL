from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.support.ui import Select
import time

# Launch the Brower
driver = webdriver.Chrome('/Users/jw/Desktop/study/naver/code/chromedriver')
driver.implicitly_wait(3)

# Naver Login
driver.get('https://nid.naver.com/nidlogin.login')
driver.find_element_by_name('id').send_keys('naver_id')
input("Press Enter to continue...")

# Club admin page
driver.get('http://cafe.naver.com/ManageWholeMember.nhn?clubid=xxxxxxxx')

# Select a membership level from a pull-down menu
select = Select(driver.find_element_by_id('_sortMemberLevel'))
select.select_by_value('130') # Membership Level
time.sleep(3)

# Select the number of items from a pull-down menu
select = Select(driver.find_element_by_id('_sortPerPage'))
select.select_by_value('100') # Number of Items in a Screen (30, 50, or 100)
time.sleep(3)

# Open a file to store the results
idFile = open('c:/temp/naver_cafe.txt', 'w')

# html parsing with BeautifulSoup
soup = BeautifulSoup(driver.page_source, 'html.parser')

# Find the total number of members (what will happen if there are more than 1000 members?)
count = int(soup.find('em', class_="_memberCount").text)

# Pause until I remove the notice about Flash 
input("Press Enter to continue...")

### You should add a loop if count is bigger than 100 ###

idElements = soup.select('div > table > tbody > tr')

for id in idElements:
	idStr = id.get('memberid')
	if idStr is not None:
		print(idStr, file=idFile)

### if there is more than one page, you should keep loading the next page in a loop
# driver.find_element_by_xpath('//*[@id="paginate"]/a[2]').click()
# soup = BeautifulSoup(driver.page_source, 'html.parser')

idFile.close()