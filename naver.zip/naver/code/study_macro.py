from selenium import webdriver

# 네이버 계정 및 앱 정보
naver_id = "aibigdata" #네이버 아이디
naver_pw = "wldnd1!" #네이버 비밀번호
naver_cid = "YtBoXTDoeKMzGgsLtQ2_" #클라이언트 아이디
naver_csec = "eDnlueWFnF" #클라이언트 시크릿
naver_redirect = "http://127.0.0.1:8000/" #리다이렉트 URI -> 아무거나 상관없음

driver = webdriver.Chrome("/Users/jw/Desktop/study/naver/code/chromedriver")

driver.implicitly_wait(3)
driver.get('https://nid.naver.com/nidlogin.login')
# 아이디/비밀번호를 입력해준다.
driver.find_element_by_name('id').send_keys(naver_id)
driver.find_element_by_name('pw').send_keys(naver_pw)
driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/input').click()