# Token 정보 가져오는 코드

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import json
import os
import re
import urllib.request

from bs4 import BeautifulSoup
from requests import get
from selenium import webdriver
from urllib.error import HTTPError
from urllib.parse import urlencode


title = "출석체크요"
content = "출석체크 합니다."


def get_naver_token():
    chromedriver_path = "/Users/jw/Desktop/study/naver/code/chromedriver"
    naver_id = "jiyounggaza" #네이버 아이디
    naver_pw = "1q2w3e4r#$" #네이버 비밀번호
    naver_cid = "Jo_Vow33m56sa64IFI5w" #클라이언트 아이디
    naver_csec = "daz_szw89a" #클라이언트 시크릿
    naver_redirect = "http://127.0.0.1:8000" #리다이렉트 URI -> 아무거나 상관없음
    driver = webdriver.Chrome(chromedriver_path)  # driver = webdriver.PhantomJS()
    driver.implicitly_wait(3)
    driver.get('https://nid.naver.com/nidlogin.login')
    driver.find_element_by_name('id').send_keys(naver_id)
    driver.find_element_by_name('pw').send_keys(naver_pw)
    driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/input').click()

    state = "REWERWERTATE"
    req_url = 'https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=%s&redirect_uri=%s&state=%s' % (naver_cid, naver_redirect, state)

    driver.get(req_url)
    ##########################
    # XXX: 최초 1회만 반드시 필요하고 이후엔 불필요함
    driver.find_element_by_xpath('//*[@id="confirm_terms"]/a[2]').click()
    ##########################
    redirect_url = driver.current_url
    print(temp)
    temp = re.split('code=', redirect_url)
    print(temp)
    code = re.split('&state=', temp)[0]
    print(code)
    driver.quit()

    print(redirect_url)

    url = 'https://nid.naver.com/oauth2.0/token?'
    data = 'grant_type=authorization_code' + '&client_id=' + naver_cid + '&client_secret=' + naver_csec + '&redirect_uri=' + naver_redirect + '&code=' + code + '&state=' + state

    request = urllib.request.Request(url, data=data.encode("utf-8"))
    request.add_header('X-Naver-Client-Id', naver_cid)
    request.add_header('X-Naver-Client-Secret', naver_redirect)
    response = urllib.request.urlopen(request)
    rescode = response.getcode()
    token = ''
    if rescode == 200:
        response_body = response.read()
        js = json.loads(response_body.decode('utf 8'))
        token = js['access_token']
    else:
        print("Error Code:", rescode)
        return None

    if len(token) == 0:
        return None
    print(token)
    return token 


def naver_cafe_post(subject, content):
    token = get_naver_token()
    header = "Bearer " + token  # Bearer 다음에 공백 추가
    clubid = '16996348'    
    menuid = '140'
    url = "https://openapi.naver.com/v1/cafe/" + clubid + "/menu/" + menuid + "/articles"

    subject = urllib.parse.quote(subject)
    content = urllib.parse.quote(content)
    data = urlencode({'subject': subject, 'content': content}).encode()
    request = urllib.request.Request(url, data=data)
    request.add_header("Authorization", header)
    try:
        response = urllib.request.urlopen(request)
    except HTTPError as e:
        print("url open failed", e, subject, content)
        return
    rescode = response.getcode()
    if rescode == 200:
        response_body = response.read()
        print(response_body.decode('utf-8'))
    else:
        print("Error Code:" + rescode)

get_naver_token()
naver_cafe_post(title, content)