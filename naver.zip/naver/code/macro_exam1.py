# -*- coding: utf-8 -*-
import os
import sys
import datetime
import time
from datetime import timedelta
from selenium import webdriver
import urllib.request
from urllib.parse import urlencode
import json
import re


# 네이버 계정 및 앱 정보
naver_id = "784wldnd" #네이버 아이디
naver_pw = "chlwldnd1!" #네이버 비밀번호
naver_cid = "aYTsvZMKlGN5WlK2XRDI" #클라이언트 아이디
naver_csec = "6fn4JXF_rn" #클라이언트 시크릿
naver_redirect = "http://127.0.0.1:8000/" #리다이렉트 URI -> 아무거나 상관없음

driver = webdriver.Chrome("/Users/jw/Desktop/study/naver/code/chromedriver")
driver.implicitly_wait(3)

# 네이버 로그인
driver.get('https://nid.naver.com/nidlogin.login')
driver.execute_script("document.getElementsByName('id')[0].value=\'"+ naver_id + "\'")
driver.execute_script("document.getElementsByName('pw')[0].value=\'"+ naver_pw + "\'")
driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/input').click()
driver.implicitly_wait(3)
driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/span[2]/a').click()

state = "SOMETHING" # 보안을 위한 문자열 -> 아무거나 상관없음

# 네아로로 이동
req_url = 'https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=%s&redirect_uri=%s&state=%s' % (naver_cid, naver_redirect, state)
driver.get(req_url)

# 처음 1회에 한해서 여기서 권한을 추가하는데, 이것은 수동으로 하는 게 편할 것 같아서 그냥 이렇게 놔둠
# 오류가 발생한다면 이까지만 실행하고 권한 추가는 수동으로 한다.
# 카페 관련 권한 체크하는 것 빼먹지 않도록 조심.
# driver.find_element_by_xpath('//*[@id="profile_optional_list"]/span/label').click()
# time.sleep(1)
# driver.find_element_by_xpath('//*[@id="content"]/div[4]/div[2]/button/span').click()
redirect_url = driver.current_url

temp = re.split('code=', redirect_url)
print(temp)
code = re.split('&state=', temp[1])[0]
print(code)
driver.quit()

url = 'https://nid.naver.com/oauth2.0/token?'
data = 'grant_type=authorization_code' + '&client_id=' + naver_cid + '&client_secret=' + naver_csec + '&redirect_uri=' + naver_redirect + '&code=' + code + '&state=' + state

request = urllib.request.Request(url, data=data.encode("utf-8"))
request.add_header('X-Naver-Client-Id', naver_cid)
request.add_header('X-Naver-Client-Secret', naver_redirect)
response = urllib.request.urlopen(request)
rescode = response.getcode()
token = ''

# 정상 작동하면 token 변수에 접근토큰이 저장된다.
if rescode == 200:
    response_body = response.read()
    js = json.loads(response_body.decode('utf 8'))
    token = js['access_token']
else:
    print("Error Code:", rescode)



post_title = "상반기 목표 평일 스터디 인원 모집합니다."
post_content = "안녕하세요 매주 평일 주2회씩 홍대에서 NCS스터디 함께하실분 모집합니다.<br>저희그룹은 현재 6분이 계시고 2분 충원중입니다.<br><br>준비물이 따로없는 그룹입니다.<br>모든 자료와 과제는 출력하여 제공해드립니다.<br>첫모임에는 정각부터 1시간동안 휴노형 NCS 모의고사 40문제를 OMR마킹연습까지 진행합니다.<br><br>풀이후 남은시간동안 자체 지각/결석/과제미준수 등에관한 패널티와 규칙을 정합니다.<br>남은시간에는 매삼비와 비타민등을 풀면서 다음시간을 위한 과제를 논의하겠습니다.<br>매주 금요일1시에는 NCS를 준비하는 다른분들을 초청하여 휴노형 모의고사를 봅니다.<br><br>희망하실경우 참여가능합니다.<br>새로오시는 분은 스터디에 참석하시고 나서 계속할지 말지 결정하시면됩니다.<br>스터디에 참석하기로 결정 하셨다면 스터디 분위기 유지와 지속적인 스터디는 보장해드립니다.<br>까닭에 첫모임 후 꼭 결정해주세요. 저희 모임에 참여해보시고 계속 하실지 말지 알려주시면됩니다.<br><br>룸비와 프린트비외에 추가비용 일절없습니다.<br>스터디후 추가 공부는 추가 룸비없이 진행중입니다.<br><br>함께하기를 희망하는분은<br>[이름/나이/성별/직무/평일 중 매주 참여가능한 시간과 요일]을 적어서 아래카톡으로 알려주세요.<br>카톡 - https://open.kakao.com/o/sMORt4lb<br>"

# 여기서부터 네이버 카페 글쓰기
header = "Bearer " + token # Bearer 다음에 공백 추가
clubid = "16996348" # 카페의 고유 ID값
menuid = "600" # (상품게시판은 입력 불가)

url = "https://openapi.naver.com/v1/cafe/" + clubid + "/menu/" + menuid + "/articles"
subject = urllib.parse.quote(post_title) # 제목
content = urllib.parse.quote(post_content) # 글 내용
data = urlencode({'subject': subject, 'content': content}).encode()
request = urllib.request.Request(url, data=data)
request.add_header("Authorization", header)
response = urllib.request.urlopen(request)
rescode = response.getcode()
if(rescode==200):
    response_body = response.read()
    print(response_body.decode('utf-8'))
else:
    print("Error Code:" + rescode)

print("이거다")

print(response_body.decode('utf-8')[1])
