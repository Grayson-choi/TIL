# -*- coding: utf-8 -*-
import os
import sys
import datetime
import time
from datetime import timedelta
from selenium import webdriver
import urllib.request
from urllib.parse import urlencode
import json
import re
from random import *


# 네이버 계정 및 앱 정보
naver_id = "784wldnd" #네이버 아이디
naver_pw = "chlwldnd1!" #네이버 비밀번호
naver_cid = "aYTsvZMKlGN5WlK2XRDI" #클라이언트 아이디
naver_csec = "jP7mWGv6i5" #클라이언트 시크릿
naver_redirect = "http://127.0.0.1:8000/" #리다이렉트 URI -> 아무거나 상관없음

options = webdriver.ChromeOptions()
options.add_argument('headless')
options.add_argument('window-size=1920x1080')
options.add_argument("disable-gpu")
# 혹은 options.add_argument("--disable-gpu")

driver = webdriver.Chrome("/Users/jw/Desktop/study/naver/code/chromedriver", chrome_options=options)

driver.implicitly_wait(3)

# 네이버 로그인
driver.get('https://nid.naver.com/nidlogin.login')
driver.execute_script("document.getElementsByName('id')[0].value=\'"+ naver_id + "\'")
driver.execute_script("document.getElementsByName('pw')[0].value=\'"+ naver_pw + "\'")
driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/input').click()
driver.implicitly_wait(3)
driver.find_element_by_xpath('//*[@id="frmNIDLogin"]/fieldset/span[2]/a').click()

state = "SOMETHING" # 보안을 위한 문자열 -> 아무거나 상관없음

# 네아로로 이동
req_url = 'https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=%s&redirect_uri=%s&state=%s' % (naver_cid, naver_redirect, state)
driver.get(req_url)

# 처음 1회에 한해서 여기서 권한을 추가하는데, 이것은 수동으로 하는 게 편할 것 같아서 그냥 이렇게 놔둠
# 오류가 발생한다면 이까지만 실행하고 권한 추가는 수동으로 한다.
# 카페 관련 권한 체크하는 것 빼먹지 않도록 조심.
# driver.find_element_by_xpath('//*[@id="profile_optional_list"]/span/label').click()
# time.sleep(1)
# driver.find_element_by_xpath('//*[@id="content"]/div[4]/div[2]/button/span').click()
redirect_url = driver.current_url

temp = re.split('code=', redirect_url)
code = re.split('&state=', temp[1])[0]
driver.quit()

url = 'https://nid.naver.com/oauth2.0/token?'
data = 'grant_type=authorization_code' + '&client_id=' + naver_cid + '&client_secret=' + naver_csec + '&redirect_uri=' + naver_redirect + '&code=' + code + '&state=' + state

request = urllib.request.Request(url, data=data.encode("utf-8"))
request.add_header('X-Naver-Client-Id', naver_cid)
request.add_header('X-Naver-Client-Secret', naver_redirect)
response = urllib.request.urlopen(request)
rescode = response.getcode()
token = ''

# 정상 작동하면 token 변수에 접근토큰이 저장된다.
if rescode == 200:
    response_body = response.read()
    js = json.loads(response_body.decode('utf 8'))
    token = js['access_token']
else:
    print("Error Code:", rescode)


ncs_title_list = ["상반기 목표 평일 스터디 인원 모집합니다.",
"평일 NCS 스터디 모집합니다. 주2회 3시간",
"NCS 평일 오전 스파르타스터디 모집합니다.",
"새로시작하는 NCS 스터디 모임모집합니다. 사유있어도 결석시 패널티 있음.",
"NCS 처음하시는분도 함께가능해요! NCS 스터디 모집!",
"NCS 스터디 휴노형,모듈형 두루 준비합니다. 평일 오전 주2회씩 시간되시는분!",
"NCS 상반기 목표 기술직 사무직 혼합 봉모&리뷰 스터디 모집.",
"NCS 스터디 모집",
"NCS 봉모 같이 푸실분 구합니다. 2명 충원",
"NCS 스터디 모집합니다. 처음하는 분도 도와드립니다.",
"NCS 기본서한권푸신분이라면 함께가능해요! NCS 스터디 모집!"]

ncs_content_list = ["안녕하세요 매주 평일 주2회씩 홍대에서 NCS스터디 함께하실분 모집합니다.<br>저희그룹은 현재 6분이 계시고 2분 충원중입니다.<br><br>준비물이 따로없는 그룹입니다.<br>모든 자료와 과제는 출력하여 제공해드립니다.<br>첫모임에는 정각부터 1시간동안 휴노형 NCS 모의고사 40문제를 OMR마킹연습까지 진행합니다.<br><br>풀이후 남은시간동안 자체 지각/결석/과제미준수 등에관한 패널티와 규칙을 정합니다.<br>남은시간에는 매삼비와 비타민등을 풀면서 다음시간을 위한 과제를 논의하겠습니다.<br>매주 금요일1시에는 NCS를 준비하는 다른분들을 초청하여 휴노형 모의고사를 봅니다.<br><br>희망하실경우 참여가능합니다.<br>새로오시는 분은 스터디에 참석하시고 나서 계속할지 말지 결정하시면됩니다.<br>스터디에 참석하기로 결정 하셨다면 스터디 분위기 유지와 지속적인 스터디는 보장해드립니다.<br>까닭에 첫모임 후 꼭 결정해주세요. 저희 모임에 참여해보시고 계속 하실지 말지 알려주시면됩니다.<br><br>룸비와 프린트비외에 추가비용 일절없습니다.<br>스터디후 추가 공부는 추가 룸비없이 진행중입니다.<br><br>함께하기를 희망하는분은<br>[이름/나이/성별/직무/평일 중 매주 참여가능한 시간과 요일]을 적어서 아래카톡으로 알려주세요.<br>카톡 - https://open.kakao.com/o/sMORt4lb<br>",
"평일 홍대에서 함께하실 NCS 스터디원 모집합니다.<br>매주 평일 3시간씩 주2회씩 모이는 스터디입니다.<br>과제가 매일있고 주2회씩 모이는 스터디라 푸는양이 좀 됩니다.<br>잘하실필요는 없고 기본서 한권정도 푸신분이 함께해주시면 감사하겠습니다.<br>고난도 PSAT문제 위주로 풀고있고 시간 정해서 풀이후에<br>각자 어떻게 풀었는지 서로에게 리뷰해주면서 진행합니다.<br>과제와 풀자료는 파일들 있어서 매번 무료로 나눠드립니다.<br>기술직하고 사무직 반반 섞여있는 그룹이에요.<br>열심히 참여가능한분 카톡으로 양식 보내주세요.<br><br>NCS스터디는 나태해지기 정말 쉽습니다.<br>패널티와 보증금 강하게 있습니다.<br><br>양식 - 이름/나이/성별/직무/시작 가능한날짜/매주 참여가능한 요일과 시간<br>카톡 - https://open.kakao.com/o/sMORt4lb<br>",
"매주 홍대에서 함께하는 NCS스터디 모집합니다.<br><br>첫 모임에는 40문제 휴노형 모의고사를 OMR마킹까지 함께하면서<br>서로의 수준을 파악하겠습니다.<br>모의고사 리뷰후에는 매삼비와 비타민으로 남은시간을 채울예정입니다.<br><br>첫 모임간 모의고사풀이와 함께 스터디하신 뒤에 계속하기로 결정하시면되고<br>계속 하시기로 마음이 드셨다면<br>저희모임에는 지각/결석/과제미준수와 관련된 패널티가 있습니다.<br><br>빠지지않고열심히 나오실 수 있는분만 참여 부탁드립니다.<br><br>스터디에 함께하고 싶으신분은 아래 카톡링크로 양식 보내주세요.<br>양식 - [이름/나이/성별/직무/매주 참여가능한 시간과 요일]<br>카톡 - https://open.kakao.com/o/sMORt4lb<br>",
"주2회 평일 오후3시부터 또는 이전 중 시간 가능하신분 모집합니다.<br>2분 정도 충원하고 있습니다.<br>기본서 한권정도 푸신분이면 좋습니다.<br>3시간씩 모이구요 주2회 스터디합니다.<br>과제있으면 과제리뷰후 시간 재고 봉투모의고사 아무기업이나 풀꺼에요.<br>리뷰하고 시간이남으면 PSAT문제나 고난도 문제 15개 내외 풀고 리뷰하면서 마무리합니다.<br>잘하려고 모이는 스터디이기때문에 잘하지않아도 참여하는데 상관없습니다.<br><br>같이 열심히 주2회만 꼭 지켜서 함께 열심히해봐요.<br>주2회 지키는것 쉬워보이지만 어렵습니다.<br>혼자하면 나태해지기때문에 스터디하는거잖아요.<br>열심히 빠지지않고 나오실분 연락주세요.<br><br>장소는 홍대구요<br>이름/나이/평일중 매주 빠지지않고 참여가능한 요일과 시간/직무/NCS경험 적어서<br>https://open.kakao.com/o/sMORt4lb  여기로 카톡주세요.<br>",
"매주 홍대에서 평일 오전12시또는 3시에 NCS모의고사 주2회 스터디 함께하실분 모집합니다.<br>휴노형과 모듈형 PSAT고난도 민경채 등 자료준비해드리구요.<br>3시간씩 과제 리뷰와 모의고사 풀이 고난도 문제까지 좀 타이트하게 진행하는편입니다.<br>추가로 희망하실경우 매주 금요일 1시에 NCS모의고사 풀면서 현재 실력 파악하고 다른 새로운분들과<br>교류하기도 합니다. 성실하게 매주 빠지지않고 나올 수 있는분 계시면 연락주세요.<br>카톡 - https://open.kakao.com/o/sMORt4lb<br>"]

post_title = ncs_title_list[randint(0,11)]
post_content = ncs_content_list[randint(0,5)]


# 여기서부터 네이버 카페 글쓰기
header = "Bearer " + token # Bearer 다음에 공백 추가
clubid = "21737991" # 카페의 고유 ID값
menuid = "169" # (상품게시판은 입력 불가)

url = "https://openapi.naver.com/v1/cafe/" + clubid + "/menu/" + menuid + "/articles"
subject = urllib.parse.quote(post_title) # 제목
content = urllib.parse.quote(post_content) # 글 내용
data = urlencode({'subject': subject, 'content': content}).encode()
request = urllib.request.Request(url, data=data)
request.add_header("Authorization", header)
response = urllib.request.urlopen(request)
rescode = response.getcode()
if(rescode==200):
    response_body = response.read()
    print(response_body.decode('utf-8'))
else:
    print("Error Code:" + rescode)
time.sleep(10)






