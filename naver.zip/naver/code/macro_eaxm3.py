# -*- coding: utf-8 -*-
# 1번 아이디
import os
import sys
import datetime
import time
from datetime import timedelta
from selenium import webdriver
import urllib.request
from urllib.parse import urlencode
import json
import re
from bs4 import BeautifulSoup
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By



# 네이버 계정 및 앱 정보
naver_id = "aibigdata" #네이버 아이디
naver_pw = "wldnd1!" #네이버 비밀번호
naver_cid = "YtBoXTDoeKMzGgsLtQ2_" #클라이언트 아이디
naver_csec = "eDnlueWFnF" #클라이언트 시크릿
naver_redirect = "http://127.0.0.1:8000/" #리다이렉트 URI -> 아무거나 상관없음

post_title = "Test해봅니다."
post_content = "안녕하세요."


driver = webdriver.Chrome("/Users/jw/Desktop/study/naver/code/chromedriver")

driver.implicitly_wait(3)


try:
    #로그인
    driver.get('http://nid.naver.com/nidlogin.login')
    time.sleep(1)
    tag_id = driver.find_element_by_id('id')
    tag_id.send_keys(naver_id)
    tag_pw = driver.find_element_by_id('pw')
    tag_pw.send_keys(naver_pw)
    tag_pw.submit()
    time.sleep(10)
    #카페 글쓰기
    time.sleep(1)
    #카페 주소
    driver.get('https://cafe.naver.com/dokchi')
    driver.find_element(By.CLASS_NAME, '_rosRestrict').click()
    # driver.find_element(By.ID, 'menuLink8718').click()
    #메뉴 고르기
    # select = Select(driver.find_element_by_name('140'))
    # 값으로 선택하기 select.select_by_value('1')
    # select.select_by_visible_text('')
    #제목 쓰기
    field = driver.find_elements_by_css_selector('input[name=subject')[0]
    field.clear()
    field.send_keys(post_title)
    #내용 쓰기.
    iframe = driver.find_elements_by_css_selector('iframe')[0]
    driver.switch_to_frame(iframe)
    body = driver.find_element_by_id('body')
    body.click()
    body.send_keys(post_content)
    #글올리기
    driver.switch_to_default_content()
    driver.find_element_by_css_selector('[class*=Submit]').click()()
finally:
    pass
