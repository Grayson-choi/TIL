module KakaoHelper
end
