class Emd < ApplicationRecord
  belongs_to :gusigun
end
