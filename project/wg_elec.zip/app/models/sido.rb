class Sido < ApplicationRecord
  has_many :gusigun
end
