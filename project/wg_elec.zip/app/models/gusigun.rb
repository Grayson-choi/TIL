class Gusigun < ApplicationRecord
  belongs_to :sido
  has_many :emd
end
