require 'test_helper'

class GusigunTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
