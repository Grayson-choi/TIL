require 'test_helper'

class EmdTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
